// Dummy data for login
var dummyUsername = 'admin';
var dummyPassword = 'password';
